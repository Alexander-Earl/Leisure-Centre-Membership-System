
Enumerations
============

Documentation for the various enumerations used for |docx| property settings
can be found here:

.. toctree::
   :titlesonly:

   MsoColorType
   MsoThemeColorIndex
   WdAlignParagraph
   WdBuiltinStyle
   WdColorIndex
   WdLineSpacing
   WdOrientation
   WdRowAlignment
   WdSectionStart
   WdStyleType
   WdTabAlignment
   WdTabLeader
   WdTableDirection
   WdUnderline
